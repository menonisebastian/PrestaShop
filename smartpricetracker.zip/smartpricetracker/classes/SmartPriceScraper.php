<?php
/**
 * Clase para realizar la extracción (Scraping) limpia
 */

class SmartPriceScraper
{
    /**
     * Obtiene el precio de una URL buscando el JSON-LD (Schema.org)
     * * @param string $url URL del competidor
     * @return float|bool Retorna el precio o false si falla
     */
    public static function getCompetitorPrice($url)
    {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        // Timeout corto para no colapsar nuestro servidor si el otro tarda en responder
        curl_setopt($ch, CURLOPT_TIMEOUT, 6); 
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
        
        $html = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode != 200 || empty($html)) {
            return false;
        }

        // Parsear el HTML
        $dom = new DOMDocument();
        // Suprimir advertencias de HTML mal formado
        @$dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
        $xpath = new DOMXPath($dom);

        // Buscar Datos Estructurados (JSON-LD)
        $scripts = $xpath->query('//script[@type="application/ld+json"]');
        
        foreach ($scripts as $script) {
            $data = json_decode($script->nodeValue, true);
            if (!$data) continue;
            
            // Yoast y RankMath suelen meter todo dentro de un array "@graph"
            if (isset($data['@graph'])) {
                $data = $data['@graph'];
            }

            if (is_array($data)) {
                $price = self::extractPriceFromSchema($data);
                if ($price !== false) return $price;
            } else {
                $price = self::extractPriceFromSchema([$data]);
                if ($price !== false) return $price;
            }
        }

        return false;
    }

    /**
     * Función recursiva auxiliar para buscar la propiedad 'price'
     */
    private static function extractPriceFromSchema($schemaArray)
    {
        foreach ($schemaArray as $item) {
            if (isset($item['@type'])) {
                $type = is_array($item['@type']) ? $item['@type'][0] : $item['@type'];
                
                // Tipo Product suele tener una propiedad "offers"
                if ($type === 'Product' && isset($item['offers'])) {
                    $offers = is_array($item['offers']) && isset($item['offers'][0]) ? $item['offers'][0] : $item['offers'];
                    if (isset($offers['price'])) {
                        return (float) $offers['price'];
                    }
                } 
                // A veces es directamente una entidad Offer
                elseif ($type === 'Offer' && isset($item['price'])) {
                    return (float) $item['price'];
                }
            }
        }
        return false;
    }
}